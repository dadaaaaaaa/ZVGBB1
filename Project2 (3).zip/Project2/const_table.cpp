#pragma once
#include <iostream>
#include <fstream>
#include <unordered_set>
#include <vector>
#include "lexeme.h"
using namespace std;

// ���-������� ��� �����
struct string_hash {
    size_t operator()(const string& str) const {
        return hash<string>()(str);
    }
};

template <typename Table_type> class const_table {
private:
    unordered_set<Table_type, string_hash> table;  // ���������� unordered_set � ���-��������
public:
    const_table() {}
    const_table(string f_name) {
        read_file(f_name);
    }
    ~const_table() {
        table.clear();
    }
    bool read_file(string f_name) {
        ifstream inf(f_name.c_str(), ios::in);
        if (inf.is_open()) {
            Table_type elem;
            while (!inf.eof()) {
                inf >> elem;
                table.insert(elem);
            }
            inf.close();
            return true;
        }
        else
            return false;
    }
    void add_elem(Table_type elem) {
        if (!contains(elem)) table.insert(elem);
    }
    bool contains(Table_type elem) {
        return table.find(elem) != table.end();
    }
    int get_num(Table_type elem) {
        if (contains(elem))
            return distance(table.begin(), table.find(elem));
        else
            return -1;
    }
    const Table_type* get_val(int num) {
        if (num < 0 || num >= table.size()) return NULL;
        auto iter = table.begin();
        advance(iter, num);
        return &(*iter);
    }
};

class lexeme_table {
private:
    vector<lexeme> table;
public:
    lexeme_table() {}
    lexeme_table(string f_name) {
        read_file(f_name);
    }
    bool read_file(string f_name) {
        ifstream inf(f_name.c_str(), ios::in);
        if (inf.is_open()) {
            string name;
            while (!inf.eof()) {
                inf >> name;
                add_lexeme(name);
            }
            inf.close();
            return true;
        }
        else
            return false;
    }
    void add_lexeme(string _lexeme) {
        table.push_back(lexeme(_lexeme));
    }
    const lexeme* get_lexeme(string name) {
        for (auto iter = table.begin(); iter != table.end(); iter++) {
            if (iter->name == name)
                return &(*iter);
        }
        return NULL;
    }
    const lexeme* get_lexeme(int num) {
        if (num < 0 || num >= table.size()) return NULL;
        auto iter = table.begin();
        advance(iter, num);
        return &(*iter);
    }
    bool contains(string name) {
        for (auto iter = table.begin(); iter < table.end(); iter++) {
            if (iter->name == name) return true;
        }
        return false;
    }
    int get_num(string name) {
        for (auto iter = table.begin(); iter < table.end(); iter++) {
            if (iter->name == name) return distance(table.begin(), iter);
        }
        return -1;
    }
};