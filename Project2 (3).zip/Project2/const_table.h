#pragma once
#include <iostream>
#include <fstream>
#include <set>

template <typename T> class const_table {
private:
	std::set<T> table;
public:
	const_table() {}
	~const_table() {
		table.clear();
	}

	bool input(std::string filename) {
		std::ifstream in(filename.c_str());
		if (!in.is_open())
			return false;

		T elem;
		while (!in.eof()) {
			in >> elem;
			table.insert(elem);
		}
		in.close();
		return true;
	}

	void add_elem(T elem) {
		table.insert(elem);
	}

	bool contains(T elem) {
		return table.find(elem) != table.end();
	}
	int get_num(T elem) {
		return contains(elem) ? distance(table.begin(), table.find(elem)) : -1;
	}
	const T* get_val(int num) {
		if (num < 0 || num >= table.size())
			return NULL;
		auto iter = table.begin();
		std::advance(iter, num);
		return &(*iter);
	}
};
