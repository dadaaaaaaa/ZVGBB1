#pragma once

#include <iostream>
#include <fstream>
#include <set>
#include "lexeme.h"

class var_table {
private:
	std::vector<lexeme> table;
public:
	var_table() {}
	~var_table() {
		table.clear();
	}

	void add_elem(std::string elem) {
		table.push_back(lexeme(elem));
	}
	lexeme* get_elem(std::string elem) {
		for (auto iter = table.begin(); iter != table.end(); iter++)
			if (iter->name == elem)
				return &(*iter);
		return NULL;
	}
	lexeme* get_elem(int num) {
		if (num < 0 || num >= table.size())
			return NULL;
		auto iter = table.begin();
		std::advance(iter, num);
		return &(*iter);
	}

	bool contains(std::string elem) {
		for (auto iter = table.begin(); iter != table.end(); iter++)
			if (iter->name == elem)
				return true;
		return false;
	}
	int get_num(std::string elem) {
		for (auto iter = table.begin(); iter != table.end(); iter++)
			if (iter->name == elem)
				return distance(table.begin(), iter);
		return -1;
	}

	void set_type(std::string elem, int type) {
		for (auto iter = table.begin(); iter != table.end(); iter++)
			if (iter->name == elem)
				iter->type = type;
	}
};
